-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql101.infinityfree.com
-- Generation Time: Oct 27, 2026 at 04:43 AM
-- Server version: 11.4.13-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_42944056_wildvista`
--

-- --------------------------------------------------------

--
-- Table structure for table `accommodations`
--

CREATE TABLE `accommodations` (
  `id` int(11) NOT NULL,
  `operator_id` int(11) DEFAULT NULL,
  `name` varchar(180) NOT NULL,
  `type` varchar(80) NOT NULL,
  `location` varchar(180) NOT NULL,
  `description` text NOT NULL,
  `amenities` text DEFAULT NULL,
  `price_per_night` decimal(12,2) NOT NULL DEFAULT 0.00,
  `max_guests` int(11) NOT NULL DEFAULT 2,
  `image` varchar(255) DEFAULT NULL,
  `status` enum('active','pending','draft','rejected') NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `accommodations`
--

INSERT INTO `accommodations` (`id`, `operator_id`, `name`, `type`, `location`, `description`, `amenities`, `price_per_night`, `max_guests`, `image`, `status`, `created_at`) VALUES
(1, 2, 'Arusha Coffee Lodge', 'Lodge', 'Arusha', 'A calm lodge-style stay with gardens, spacious rooms and easy access to Arusha-based departures.', 'Breakfast, Wi-Fi, Restaurant, Pool, Parking', '250.00', 2, 'accommodation.svg', 'active', '2026-09-17 11:16:25'),
(2, 2, 'The Baobab Hotel', 'Hotel', 'Arusha', 'A comfortable city stay suited to travellers who want a central base before or after a trip.', 'Wi-Fi, Restaurant, Parking, Airport transfer on request', '160.00', 2, 'lodgemountain.svg', 'active', '2026-09-17 11:16:25'),
(3, NULL, 'Meru Horizon Camp', 'Camp', 'Near Arusha', 'Sample accommodation listing prepared for future verification and activation.', 'Tents, Dining area, Nature views', '220.00', 3, 'activity.svg', 'pending', '2026-09-17 11:16:25'),
(4, NULL, 'Private Arusha Villa', 'Private accommodation', 'Arusha', 'A demo private-stay listing. The owner can later claim and manage this listing through the operator workflow.', 'Kitchen, Wi-Fi, Parking, Private rooms', '180.00', 4, 'accommodation.svg', 'pending', '2026-09-17 11:16:25');

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `id` int(11) NOT NULL,
  `operator_id` int(11) DEFAULT NULL,
  `name` varchar(180) NOT NULL,
  `description` text NOT NULL,
  `duration_hours` decimal(5,1) NOT NULL DEFAULT 2.0,
  `price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `image` varchar(255) DEFAULT NULL,
  `status` enum('active','pending','draft','rejected') NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`id`, `operator_id`, `name`, `description`, `duration_hours`, `price`, `image`, `status`, `created_at`) VALUES
(1, 2, 'Arusha Food & Makers Walk', 'Taste local flavours, see makers at work and explore Arusha with a local guide.', '4.0', '70.00', 'culture.svg', 'active', '2026-09-17 11:16:26'),
(2, 2, 'Sunset Mount Meru View', 'A relaxed scenic experience designed around viewpoints and golden-hour photography.', '3.0', '55.00', 'meru.svg', 'active', '2026-09-17 11:16:26'),
(3, NULL, 'Private Coffee Experience', 'Pending sample activity waiting for an operator to activate it.', '2.0', '45.00', 'activity.svg', 'active', '2026-09-17 11:16:26');

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(160) NOT NULL,
  `entity` varchar(80) NOT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `meta` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity`, `entity_id`, `meta`, `created_at`) VALUES
(1, 1, 'login', '0', 1, NULL, '2026-09-17 11:22:26'),
(2, 1, 'created_booking', '0', 2, '{\"reference\":\"WV-E7935B2F\",\"amount\":3165}', '2026-09-17 11:27:29'),
(3, 1, 'logout', '0', 1, NULL, '2026-09-17 11:28:31'),
(4, NULL, 'logout', '0', NULL, NULL, '2026-09-17 11:28:36'),
(5, NULL, 'logout', '0', NULL, NULL, '2026-09-17 11:28:38'),
(6, NULL, 'logout', '0', NULL, NULL, '2026-09-17 11:28:39'),
(7, NULL, 'logout', '0', NULL, NULL, '2026-09-17 11:28:40'),
(8, NULL, 'logout', '0', NULL, NULL, '2026-09-17 11:28:42'),
(9, 1, 'login', '0', 1, NULL, '2026-09-18 23:32:38'),
(10, 1, 'logout', '0', 1, NULL, '2026-09-18 23:51:59'),
(11, NULL, 'created_booking', '0', 3, '{\"reference\":\"WV-8F99ED17\",\"amount\":2895}', '2026-09-18 23:58:55'),
(12, NULL, 'created_booking', '0', 4, '{\"reference\":\"WV-063979F8\",\"amount\":2895}', '2026-09-18 23:59:10'),
(13, NULL, 'created_booking', '0', 5, '{\"reference\":\"WV-DA7D0025\",\"amount\":2895}', '2026-09-18 23:59:22'),
(14, NULL, 'created_booking', '0', 6, '{\"reference\":\"WV-D9DD3AF8\",\"amount\":2895}', '2026-09-18 23:59:29'),
(15, 1, 'login', '0', 1, NULL, '2026-09-19 00:24:21'),
(16, 1, 'logout', '0', 1, NULL, '2026-09-19 00:47:07'),
(17, NULL, 'logout', '0', NULL, NULL, '2026-09-19 00:47:10'),
(18, NULL, 'logout', '0', NULL, NULL, '2026-09-19 00:47:11'),
(19, 1, 'login', '0', 1, NULL, '2026-09-20 05:09:10'),
(20, 1, 'logout', '0', 1, NULL, '2026-09-20 05:15:44'),
(21, NULL, 'logout', '0', NULL, NULL, '2026-09-20 05:15:47'),
(22, 4, 'logout', '0', 4, NULL, '2026-09-20 05:34:13'),
(23, 4, 'login', '0', 4, NULL, '2026-09-20 07:52:39'),
(24, 4, 'logout', '0', 4, NULL, '2026-09-20 08:45:06'),
(25, 1, 'login', '0', 1, NULL, '2026-09-20 08:55:07'),
(26, 1, 'logout', '0', 1, NULL, '2026-09-20 08:58:15'),
(27, NULL, 'logout', '0', NULL, NULL, '2026-09-20 09:04:39'),
(28, NULL, 'logout', '0', NULL, NULL, '2026-09-20 09:04:49'),
(29, NULL, 'logout', '0', NULL, NULL, '2026-09-20 09:04:50'),
(30, NULL, 'logout', '0', NULL, NULL, '2026-09-20 09:06:05'),
(31, NULL, 'logout', '0', NULL, NULL, '2026-09-20 09:06:40'),
(32, NULL, 'logout', '0', NULL, NULL, '2026-09-20 09:06:51'),
(33, 4, 'login', '0', 4, NULL, '2026-09-20 09:09:12'),
(34, 1, 'login', '0', 1, NULL, '2026-09-21 05:28:04'),
(35, 1, 'login', '0', 1, NULL, '2026-09-22 10:04:38'),
(36, 1, 'listing_status', '0', 4, '{\"table\":\"tours\",\"status\":\"active\"}', '2026-09-22 10:05:38'),
(37, 1, 'listing_status', '0', 3, '{\"table\":\"activities\",\"status\":\"active\"}', '2026-09-22 10:06:32'),
(38, 1, 'listing_status', '0', 3, '{\"table\":\"transports\",\"status\":\"active\"}', '2026-09-22 10:06:38'),
(39, 1, 'login', '0', 1, NULL, '2026-09-22 10:07:56'),
(40, 1, 'edit_tour', '0', 4, '{\"title\":\"Lodge-to-Park Day Safari\",\"base_price\":260,\"status\":\"active\"}', '2026-09-22 10:08:35'),
(41, 1, 'edit_tour', '0', 3, '{\"title\":\"Arusha Culture & Makers Day\",\"base_price\":180,\"status\":\"active\"}', '2026-09-22 10:09:07'),
(42, 1, 'edit_tour', '0', 2, '{\"title\":\"5 Days Northern Circuit Safari\",\"base_price\":1250,\"status\":\"active\"}', '2026-09-22 10:09:32'),
(43, 1, 'edit_tour', '0', 1, '{\"title\":\"Mount Meru Wild Escape\",\"base_price\":640,\"status\":\"active\"}', '2026-09-22 10:09:48'),
(44, 4, 'login', '0', 4, NULL, '2026-09-22 10:11:18'),
(45, 4, 'payment_submitted', '0', 5, '{\"booking\":\"WV-D9DD3AF8\",\"method\":\"mobile_money\",\"reference\":\"26604545912012\"}', '2026-09-22 10:14:14'),
(46, 1, 'login', '0', 1, NULL, '2026-09-22 10:15:41'),
(47, 1, 'approve_payment', '0', 5, '{\"booking_id\":6}', '2026-09-22 10:16:52'),
(48, 1, 'reject_payment', '0', 4, '{\"booking_id\":5}', '2026-09-22 10:17:04'),
(49, 1, 'reject_payment', '0', 3, '{\"booking_id\":4}', '2026-09-22 10:17:09'),
(50, 1, 'reject_payment', '0', 2, '{\"booking_id\":3}', '2026-09-22 10:17:12'),
(51, 1, 'reject_payment', '0', 1, '{\"booking_id\":2}', '2026-09-22 10:17:17'),
(52, 1, 'login', '0', 1, NULL, '2026-09-30 02:24:11'),
(53, 1, 'login', '0', 1, NULL, '2026-10-23 00:04:23');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `reference` varchar(30) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `tour_id` int(11) NOT NULL,
  `booking_date` date NOT NULL,
  `guests` int(11) NOT NULL DEFAULT 1,
  `accommodation_id` int(11) DEFAULT NULL,
  `accommodation_nights` int(11) NOT NULL DEFAULT 0,
  `transport_id` int(11) DEFAULT NULL,
  `total_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `status` enum('pending_payment','confirmed','cancelled','completed') NOT NULL DEFAULT 'pending_payment',
  `payment_status` enum('unpaid','pending','paid','failed','refunded') NOT NULL DEFAULT 'unpaid',
  `customer_name` varchar(120) NOT NULL,
  `customer_email` varchar(190) NOT NULL,
  `customer_phone` varchar(40) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `reference`, `customer_id`, `tour_id`, `booking_date`, `guests`, `accommodation_id`, `accommodation_nights`, `transport_id`, `total_amount`, `status`, `payment_status`, `customer_name`, `customer_email`, `customer_phone`, `notes`, `created_at`) VALUES
(1, 'WV-AQIL01', 3, 2, '2026-10-15', 2, 1, 4, 1, '3680.00', 'pending_payment', 'unpaid', 'Aqil', 'aqil@wildvista.test', '+255 760 000 002', 'Sample booking for demo dashboard.', '2026-09-17 11:16:26'),
(2, 'WV-E7935B2F', 1, 2, '2026-09-18', 2, 2, 3, 2, '3165.00', 'pending_payment', 'failed', 'Akily', 'akilykaaya@gmail.com', '+255 794 872 433', 'Special travel', '2026-09-17 11:27:29'),
(3, 'WV-8F99ED17', NULL, 2, '2026-09-20', 2, 2, 2, 2, '2895.00', 'pending_payment', 'failed', 'Meshack Kaaya', 'meshackkaaya50@gmail.com', '+255 794 872 433', 'Travel', '2026-09-18 23:58:55'),
(4, 'WV-063979F8', NULL, 2, '2026-09-20', 2, 2, 2, 2, '2895.00', 'pending_payment', 'failed', 'Meshack Kaaya', 'meshackkaaya50@gmail.com', '+255 794 872 433', 'Travel', '2026-09-18 23:59:10'),
(5, 'WV-DA7D0025', NULL, 2, '2026-09-20', 2, 2, 2, 2, '2895.00', 'pending_payment', 'failed', 'Meshack Kaaya', 'meshackkaaya50@gmail.com', '+255 794 872 433', 'Travel', '2026-09-18 23:59:22'),
(6, 'WV-D9DD3AF8', NULL, 2, '2026-09-20', 2, 2, 2, 2, '2895.00', 'confirmed', 'paid', 'Meshack Kaaya', 'meshackkaaya50@gmail.com', '+255 794 872 433', 'Travel', '2026-09-18 23:59:29');

-- --------------------------------------------------------

--
-- Table structure for table `booking_items`
--

CREATE TABLE `booking_items` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `item_type` enum('tour','accommodation','transport','activity','extra') NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `item_name` varchar(180) NOT NULL,
  `qty` decimal(10,2) NOT NULL DEFAULT 1.00,
  `unit_price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_price` decimal(12,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `booking_items`
--

INSERT INTO `booking_items` (`id`, `booking_id`, `item_type`, `item_id`, `item_name`, `qty`, `unit_price`, `total_price`) VALUES
(1, 1, 'tour', 2, '5 Days Northern Circuit Safari', '2.00', '1250.00', '2500.00'),
(2, 1, 'accommodation', 1, 'Arusha Coffee Lodge', '4.00', '250.00', '1000.00'),
(3, 1, 'transport', 1, '4×4 Safari Vehicle', '1.00', '180.00', '180.00'),
(4, 2, 'tour', 2, '5', '2.00', '1250.00', '2500.00'),
(5, 2, 'accommodation', 2, '0', '3.00', '160.00', '480.00'),
(6, 2, 'transport', 2, '0', '1.00', '75.00', '75.00'),
(7, 2, 'activity', 2, '0', '2.00', '55.00', '110.00'),
(8, 3, 'tour', 2, '5', '2.00', '1250.00', '2500.00'),
(9, 3, 'accommodation', 2, '0', '2.00', '160.00', '320.00'),
(10, 3, 'transport', 2, '0', '1.00', '75.00', '75.00'),
(11, 4, 'tour', 2, '5', '2.00', '1250.00', '2500.00'),
(12, 4, 'accommodation', 2, '0', '2.00', '160.00', '320.00'),
(13, 4, 'transport', 2, '0', '1.00', '75.00', '75.00'),
(14, 5, 'tour', 2, '5', '2.00', '1250.00', '2500.00'),
(15, 5, 'accommodation', 2, '0', '2.00', '160.00', '320.00'),
(16, 5, 'transport', 2, '0', '1.00', '75.00', '75.00'),
(17, 6, 'tour', 2, '5', '2.00', '1250.00', '2500.00'),
(18, 6, 'accommodation', 2, '0', '2.00', '160.00', '320.00'),
(19, 6, 'transport', 2, '0', '1.00', '75.00', '75.00');

-- --------------------------------------------------------

--
-- Table structure for table `destinations`
--

CREATE TABLE `destinations` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(180) NOT NULL,
  `description` text NOT NULL,
  `area` varchar(120) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` enum('active','pending','draft') NOT NULL DEFAULT 'pending',
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `destinations`
--

INSERT INTO `destinations` (`id`, `name`, `slug`, `description`, `area`, `image`, `status`, `created_by`, `created_at`) VALUES
(1, 'Arusha City', 'arusha-city', 'A lively gateway to northern safari country, full of food, culture, craft markets and easy access to outdoor experiences.', 'Arusha', 'park.svg', 'active', 1, '2026-09-17 11:16:25'),
(2, 'Mount Meru', 'mount-meru', 'A dramatic mountain adventure overlooking Arusha, with forest trails, viewpoints and guided climbs.', 'Arusha', 'https://images.unsplash.com/photo-1709371126801-abe434d13cac?auto=format&fit=crop&w=1800&q=85', 'active', 1, '2026-09-17 11:16:25'),
(3, 'Arusha National Park', 'arusha-national-park', 'Forest, lakes, giraffes and Mount Meru scenery close to Arusha.', 'Arusha', 'https://images.unsplash.com/photo-1785687047548-3123fd6ee83b?auto=format&fit=crop&w=1800&q=85', 'active', 1, '2026-09-17 11:16:25'),
(4, 'Cultural Arusha', 'cultural-arusha', 'Immersive local experiences, village visits, food, craft and storytelling.', 'Arusha', 'culture.svg', 'active', 1, '2026-09-17 11:16:25'),
(5, 'Arusha Escapes', 'arusha-escapes', 'Relaxed outdoor experiences around Arusha, built for flexible day trips and weekend escapes.', 'Arusha', 'activity.svg', 'pending', 1, '2026-09-17 11:16:25'),
(6, 'Partner Listings — Coming Soon', 'partner-listings-coming-soon', 'More independently operated stays and services are being prepared for Wildvista verification.', 'Arusha', 'lodgemountain.svg', 'pending', 1, '2026-09-17 11:16:25'),
(7, 'Tarangire National Park', 'tarangire-national-park', 'Baobabs, elephants and open savannah landscapes on the northern safari circuit.', 'Manyara Region', 'https://images.unsplash.com/photo-1776772922039-825878fe2324?auto=format&fit=crop&w=1800&q=85', 'active', 1, '2026-09-20 03:18:58'),
(8, 'Lake Manyara National Park', 'lake-manyara-national-park', 'A scenic Rift Valley park known for wildlife, woodland and the lake ecosystem.', 'Manyara Region', 'https://images.unsplash.com/photo-1693247670444-d6eff1d03136?auto=format&fit=crop&w=1800&q=85', 'active', 1, '2026-09-20 03:18:58'),
(9, 'Ngorongoro Crater', 'ngorongoro-crater', 'A dramatic crater landscape with dense wildlife and exceptional viewpoints.', 'Arusha Region', 'https://images.unsplash.com/photo-1634662058604-b76ce3b90e6e?auto=format&fit=crop&w=1800&q=85', 'active', 1, '2026-09-20 03:18:58'),
(10, 'Serengeti National Park', 'serengeti-national-park', 'Vast plains and iconic wildlife experiences in northern Tanzania.', 'Northern Tanzania', 'https://images.unsplash.com/photo-1689479665460-dac7ee513eeb?auto=format&fit=crop&w=1800&q=85', 'active', 1, '2026-09-20 03:18:58'),
(11, 'Kilimanjaro', 'kilimanjaro', 'Tanzania’s iconic mountain and a major northern adventure destination.', 'Kilimanjaro Region', 'https://images.unsplash.com/photo-1709371126801-abe434d13cac?auto=format&fit=crop&w=1800&q=85', 'active', 1, '2026-09-20 03:18:58'),
(12, 'Zanzibar', 'zanzibar', 'Island beaches, ocean experiences and Stone Town culture.', 'Zanzibar, Tanzania', 'https://images.unsplash.com/photo-1637681126455-25b23bf7fc13?auto=format&fit=crop&w=1800&q=85', 'pending', 1, '2026-09-20 03:18:58'),
(13, 'Mount Kilimanjaro travelling', 'mount-kilimanjaro-travelling', 'Visit a mount Kilimanjaro, Explore more', 'Arusha', 'uploads/admin_20260922132116_c8ab5de0.jpg', 'active', 1, '2026-09-22 10:21:17');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `recipient_email` varchar(190) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `channel` enum('email','sms') NOT NULL,
  `subject` varchar(180) DEFAULT NULL,
  `message` text NOT NULL,
  `status` enum('queued','sent','failed') NOT NULL DEFAULT 'queued',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `booking_id`, `recipient_email`, `recipient_phone`, `channel`, `subject`, `message`, `status`, `created_at`) VALUES
(1, 2, 'akilykaaya@gmail.com', '+255 794 872 433', 'email', 'Wildvista booking received', 'Your Wildvista booking WV-E7935B2F is pending payment. Total: USD 3,165.00. Payment integration is currently in setup mode.', 'queued', '2026-09-17 11:27:29'),
(2, 3, 'meshackkaaya50@gmail.com', '+255 794 872 433', 'email', 'Wildvista booking received', 'Your Wildvista booking WV-8F99ED17 is pending payment. Total: USD 2,895.00. Payment integration is currently in setup mode.', 'queued', '2026-09-18 23:58:55'),
(3, 4, 'meshackkaaya50@gmail.com', '+255 794 872 433', 'email', 'Wildvista booking received', 'Your Wildvista booking WV-063979F8 is pending payment. Total: USD 2,895.00. Payment integration is currently in setup mode.', 'queued', '2026-09-18 23:59:10'),
(4, 5, 'meshackkaaya50@gmail.com', '+255 794 872 433', 'email', 'Wildvista booking received', 'Your Wildvista booking WV-DA7D0025 is pending payment. Total: USD 2,895.00. Payment integration is currently in setup mode.', 'queued', '2026-09-18 23:59:22'),
(5, 6, 'meshackkaaya50@gmail.com', '+255 794 872 433', 'email', 'Wildvista booking received', 'Your Wildvista booking WV-D9DD3AF8 is pending payment. Total: USD 2,895.00. Payment integration is currently in setup mode.', 'queued', '2026-09-18 23:59:29'),
(6, 6, 'meshackkaaya50@gmail.com', '+255 794 872 433', 'email', 'Wildvista payment submitted', 'Payment submitted for booking WV-D9DD3AF8. Transaction/reference: 26604545912012. Admin verification is pending.', 'queued', '2026-09-22 10:14:14');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `provider` varchar(120) NOT NULL DEFAULT 'manual',
  `method` varchar(80) NOT NULL DEFAULT 'payment_integration_pending',
  `transaction_ref` varchar(160) DEFAULT NULL,
  `proof_path` varchar(255) DEFAULT NULL,
  `customer_note` text DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `verified_by` int(11) DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `status` enum('initiated','pending','paid','failed','refunded') NOT NULL DEFAULT 'pending',
  `paid_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `booking_id`, `provider`, `method`, `transaction_ref`, `proof_path`, `customer_note`, `submitted_at`, `verified_by`, `verified_at`, `amount`, `status`, `paid_at`, `created_at`) VALUES
(1, 2, 'manual / integration pending', 'card', NULL, NULL, NULL, NULL, 1, '2026-09-22 10:17:17', '3165.00', 'failed', NULL, '2026-09-17 11:27:29'),
(2, 3, 'manual / integration pending', 'mobile_money', NULL, NULL, NULL, NULL, 1, '2026-09-22 10:17:12', '2895.00', 'failed', NULL, '2026-09-18 23:58:55'),
(3, 4, 'manual / integration pending', 'card', NULL, NULL, NULL, NULL, 1, '2026-09-22 10:17:09', '2895.00', 'failed', NULL, '2026-09-18 23:59:10'),
(4, 5, 'manual / integration pending', 'control_number', NULL, NULL, NULL, NULL, 1, '2026-09-22 10:17:04', '2895.00', 'failed', NULL, '2026-09-18 23:59:22'),
(5, 6, 'manual', 'mobile_money', '26604545912012', 'uploads/payments/payment_6_bcc0b3452f.jpg', 'Use yas to pay', '2026-09-22 10:14:14', 1, '2026-09-22 10:16:52', '2895.00', 'paid', '2026-09-22 10:16:52', '2026-09-18 23:59:29');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `key_name` varchar(80) NOT NULL,
  `value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `key_name`, `value`) VALUES
(1, 'site_name', 'Wildvista'),
(2, 'site_tagline', 'Explore Arusha Your Way'),
(3, 'support_email', 'akilykaaya@gmail.com'),
(4, 'support_phone', '+255 794 872 433 / +255 621 385 106'),
(5, 'currency', 'USD'),
(6, 'email_provider', 'SMTP not configured'),
(7, 'sms_provider', 'SMS API not configured'),
(8, 'payment_provider', 'Manual payment verification'),
(9, 'payment_mobile_money', 'Pay using Wildvista Mobile Money: +255 621 385 106. After payment, enter the transaction/reference number and submit it for admin verification.'),
(10, 'payment_paypal', 'Open the configured Wildvista PayPal payment link, complete the payment, then enter the PayPal transaction ID here. Admin verifies the transaction before the booking is confirmed.'),
(11, 'paypal_link', 'https://www.paypal.com/myaccount/'),
(14, 'payment_bank', ''),
(15, 'payment_control_number', ''),
(18, 'paypal_client_id', ''),
(19, 'paypal_secret', '');

-- --------------------------------------------------------

--
-- Table structure for table `tours`
--

CREATE TABLE `tours` (
  `id` int(11) NOT NULL,
  `operator_id` int(11) DEFAULT NULL,
  `destination_id` int(11) DEFAULT NULL,
  `title` varchar(180) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `short_description` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `duration_days` int(11) NOT NULL DEFAULT 1,
  `base_price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `price_type` enum('per_person','per_group') NOT NULL DEFAULT 'per_person',
  `max_guests` int(11) NOT NULL DEFAULT 6,
  `image` varchar(255) DEFAULT NULL,
  `status` enum('active','pending','draft','rejected') NOT NULL DEFAULT 'pending',
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tours`
--

INSERT INTO `tours` (`id`, `operator_id`, `destination_id`, `title`, `slug`, `short_description`, `description`, `duration_days`, `base_price`, `price_type`, `max_guests`, `image`, `status`, `featured`, `created_at`) VALUES
(1, 2, 2, 'Mount Meru Wild Escape', 'mount-meru-wild-escape', 'A scenic mountain experience with guided trails and big views.', 'A flexible guided Mount Meru experience designed for travellers who want mountain time, nature and memorable viewpoints without a complicated booking process.', 1, '640.00', 'per_person', 6, '0', 'active', 1, '2026-09-17 11:16:25'),
(2, 2, 3, '5 Days Northern Circuit Safari', '5-days-northern-circuit-safari', 'Wildlife, landscapes and unforgettable Arusha departure-to-return safari days.', 'A five-day Arusha-based safari journey built around wildlife, scenic drives, professional guiding and flexible add-ons for accommodation and transport.', 5, '1250.00', 'per_person', 6, '0', 'active', 1, '2026-09-17 11:16:25'),
(3, 2, 4, 'Arusha Culture & Makers Day', 'arusha-culture-makers-day', 'Meet makers, taste local food and experience Arusha beyond the safari.', 'A full-day cultural route connecting local food, craft and storytelling in and around Arusha.', 1, '180.00', 'per_person', 8, '0', 'active', 1, '2026-09-17 11:16:25'),
(4, NULL, 1, 'Lodge-to-Park Day Safari', 'lodge-to-park-day-safari', 'A pending sample package awaiting an active operator.', 'Demo listing prepared for the Wildvista catalogue.', 1, '260.00', 'per_person', 6, '0', 'active', 0, '2026-09-17 11:16:25');

-- --------------------------------------------------------

--
-- Table structure for table `transports`
--

CREATE TABLE `transports` (
  `id` int(11) NOT NULL,
  `operator_id` int(11) DEFAULT NULL,
  `name` varchar(180) NOT NULL,
  `type` varchar(80) NOT NULL,
  `description` text NOT NULL,
  `capacity` int(11) NOT NULL DEFAULT 4,
  `pickup_area` varchar(180) DEFAULT NULL,
  `price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `image` varchar(255) DEFAULT NULL,
  `status` enum('active','pending','draft','rejected') NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `transports`
--

INSERT INTO `transports` (`id`, `operator_id`, `name`, `type`, `description`, `capacity`, `pickup_area`, `price`, `image`, `status`, `created_at`) VALUES
(1, 2, '4×4 Safari Vehicle', 'Safari 4×4', 'Comfortable safari vehicle option for Arusha departures, sightseeing and park trips.', 6, 'Arusha / Airport', '180.00', 'facility-safari.svg', 'active', '2026-09-17 11:16:25'),
(2, 2, 'Private City SUV', 'Private SUV', 'Private airport transfer and city mobility option for small groups.', 4, 'Arusha / Kilimanjaro Airport', '75.00', 'lodgemountain.svg', 'active', '2026-09-17 11:16:25'),
(3, NULL, 'Shared Shuttle', 'Shared transfer', 'Pending demo transport listing that may be activated by an approved provider.', 8, 'Airport / Arusha', '35.00', 'park.svg', 'active', '2026-09-17 11:16:25');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `email` varchar(190) NOT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','operator','customer') NOT NULL DEFAULT 'customer',
  `status` enum('active','pending','suspended') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `password_hash`, `role`, `status`, `created_at`) VALUES
(1, 'Akily', 'akilykaaya@gmail.com', '+255 794 872 433', '$2y$12$7thaqAfR6BkgXaVYDC/WFeiQSpANOXoGbhqE.15ofmxPj.adiAuY2', 'admin', 'active', '2026-09-17 11:16:25'),
(2, 'Patrick', 'patrick@wildvista.test', '+255 760 000 001', '$2y$12$7thaqAfR6BkgXaVYDC/WFeiQSpANOXoGbhqE.15ofmxPj.adiAuY2', 'operator', 'active', '2026-09-17 11:16:25'),
(3, 'Aqil', 'aqil@wildvista.test', '+255 760 000 002', '$2y$12$7thaqAfR6BkgXaVYDC/WFeiQSpANOXoGbhqE.15ofmxPj.adiAuY2', 'customer', 'active', '2026-09-17 11:16:25'),
(4, 'Meshack Kaaya', 'meshackkaaya50@gmail.com', '0794872433', '$2y$10$zoOBg9vW/slkMSFj6Rx.kuVcJslTXUmE.ZKMp1ewrGziZKIVs623y', 'customer', 'active', '2026-09-20 05:26:55');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accommodations`
--
ALTER TABLE `accommodations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `operator_id` (`operator_id`);

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `operator_id` (`operator_id`);

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reference` (`reference`),
  ADD KEY `tour_id` (`tour_id`),
  ADD KEY `accommodation_id` (`accommodation_id`),
  ADD KEY `transport_id` (`transport_id`),
  ADD KEY `idx_bookings_customer_tour_date` (`customer_id`,`tour_id`,`booking_date`);

--
-- Indexes for table `booking_items`
--
ALTER TABLE `booking_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `booking_id` (`booking_id`);

--
-- Indexes for table `destinations`
--
ALTER TABLE `destinations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `booking_id` (`booking_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_payments_booking` (`booking_id`),
  ADD KEY `idx_payments_status` (`status`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key_name` (`key_name`);

--
-- Indexes for table `tours`
--
ALTER TABLE `tours`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `operator_id` (`operator_id`),
  ADD KEY `destination_id` (`destination_id`);

--
-- Indexes for table `transports`
--
ALTER TABLE `transports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `operator_id` (`operator_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accommodations`
--
ALTER TABLE `accommodations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `booking_items`
--
ALTER TABLE `booking_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `destinations`
--
ALTER TABLE `destinations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tours`
--
ALTER TABLE `tours`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `transports`
--
ALTER TABLE `transports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `accommodations`
--
ALTER TABLE `accommodations`
  ADD CONSTRAINT `accommodations_ibfk_1` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `activities`
--
ALTER TABLE `activities`
  ADD CONSTRAINT `activities_ibfk_1` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`tour_id`) REFERENCES `tours` (`id`),
  ADD CONSTRAINT `bookings_ibfk_3` FOREIGN KEY (`accommodation_id`) REFERENCES `accommodations` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `bookings_ibfk_4` FOREIGN KEY (`transport_id`) REFERENCES `transports` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `booking_items`
--
ALTER TABLE `booking_items`
  ADD CONSTRAINT `booking_items_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `destinations`
--
ALTER TABLE `destinations`
  ADD CONSTRAINT `destinations_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tours`
--
ALTER TABLE `tours`
  ADD CONSTRAINT `tours_ibfk_1` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `tours_ibfk_2` FOREIGN KEY (`destination_id`) REFERENCES `destinations` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `transports`
--
ALTER TABLE `transports`
  ADD CONSTRAINT `transports_ibfk_1` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
